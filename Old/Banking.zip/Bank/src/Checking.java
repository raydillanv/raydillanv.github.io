public class Checking extends Account {
    private int[] last10Checks = new int[10];

    public Checking() {

    }

    public Checking(String name, long taxID, double balance){
        super(name, taxID, balance);
    }

    public void writeCheck(int checkNum, double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            last10Checks[numWithdraws % 10] = checkNum;
            numWithdraws++;

        } else {
            System.out.println("Error: please insert a positive amount.");
        }
    }

    private void makeWithdraw(double amount){
        if (numWithdraws < 10) {
            last10Withdraws[numWithdraws] = amount;
        } else {
            for (int i = 0; i < 9; i++) {
                last10Withdraws[i] = last10Withdraws[i + 1];
            }
            last10Withdraws[9] = amount;
        }
        numWithdraws++;
    }
    public void display() {
        System.out.println("Checking account information:");
        super.display();
        System.out.println("Check register:");
        for (int i = 0; i < numWithdraws; i++) {
            System.out.println("Check #" + last10Checks[i] + ": $" + last10Withdraws[i]);
        }
    }


}
