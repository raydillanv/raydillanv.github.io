public class Savings extends Account {
    public Savings() {}

    public Savings(String name, long taxID, double balance) {
        super(name, taxID, balance);
    }

    public void doWithdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            makeWithdraw(amount);
        } else {
            System.out.println("Error: withdrawal amount must be positive and cannot exceed account balance.");
        }
    }

    private void makeWithdraw(double amount) {
        if (numWithdraws < 10) {
            last10Withdraws[numWithdraws] = amount;
        } else {
            for (int i = 0; i < 9; i++) {
                last10Withdraws[i] = last10Withdraws[i + 1];
            }
            last10Withdraws[9] = amount;
        }
        numWithdraws++;
    }

    public void display() {
        System.out.println("Savings account information:");
        super.display();
    }

    }
