public class CreditCard extends Account {
    private long cardNumber;
    private String[] last10charges = new String[10];

    public CreditCard() {
        super();
        this.cardNumber = 0;
    }

    public CreditCard(String name, long taxID, double balance, long cardNumber) {
        super(name, taxID, balance);
        this.cardNumber = cardNumber;
    }

    public void DebitCharge(String name, double amount) {
        if (amount > 0) {
            balance -= amount;
            makeWithdraw(amount);
            for (int i = 9; i > 0; i--) {
                last10charges[i] = last10charges[i - 1];
            }
            last10charges[0] = name;
        }
    }

    public void MakePayment(double amount) {
        if (amount > 0) {
            balance += amount;
            makeDeposit(amount);
        }
    }

    public void display() {
        System.out.println("Name: " + name + "\nTaxID: "
                + taxID + "\nCard Number: " + cardNumber
                + "\nBalance: " + balance + "\nLast 10 charges:");
        for (int i = 0; i < 10; i++) {
            if (last10charges[i] != null) {
                System.out.println(last10charges[i]);
            }
        }
        System.out.println("Last 10 deposits:");
        for (int i = 0; i < 10; i++) {
            if (last10Deposits[i] != 0) {
                System.out.println(last10Deposits[i]);
            }
        }
        System.out.println("Last 10 withdrawals:");
        for (int i = 0; i < 10; i++) {
            if (last10Withdraws[i] != 0) {
                System.out.println(last10Withdraws[i]);
            }
        }
    }

    public void makeWithdraw(double amount) {
        if (amount > 0) {
            balance -= amount;
            //makeWithdraw(amount);
        } else{
            System.out.println("Amount must me greater than 0.");
        }
    }
}
