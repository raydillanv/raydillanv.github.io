import java.util.Scanner;

public class RunBank {
    public static void main(String[] args) {
        System.out.println("Welcome to Victory * ビクトリー * Banking.");
        Scanner scan = new Scanner(System.in);
        Checking checking = new Checking("Checking", 123456, 100.0);
        Savings savings = new Savings("Savings", 654321, 100.0);
        CreditCard cc = new CreditCard("Credit Card", 1111111, 100.0,987456);

        int choice = 0;
        while (choice != 10) {
            System.out.println("Checking balance: $" + checking.getBalance() + "\nSavings balance: $" + savings.getBalance() + "\nCredit Card balance: $" + cc.getBalance() +
                    "\n\nMENU options are:\n1. Savings Deposit\n2. Savings Withdrawal\n3. Checking Deposit\n4. " +
                    "Write A Check\n5. Credit Card Payment\n6. Make A Charge\n7. Display Savings\n8. " +
                    "Display Checking\n9. Display Credit Card\n10. Exit\nEnter your choice: ");
            choice = scan.nextInt();
            double amount;
            String name;
            int checkNum;
            switch (choice) {
                case 1 -> {
                    System.out.print("Enter deposit amount: ");
                    amount = scan.nextDouble();
                    savings.makeDeposit(amount);
                }
                case 2 -> {
                    System.out.print("Enter withdrawal amount: ");
                    amount = scan.nextDouble();
                    savings.doWithdraw(amount);
                }
                case 3 -> {
                    System.out.print("Enter deposit amount: ");
                    amount = scan.nextDouble();
                    checking.makeDeposit(amount);
                }
                case 4 -> {
                    System.out.print("Enter check number: ");
                    checkNum = scan.nextInt();
                    System.out.print("Enter check amount: ");
                    amount = scan.nextDouble();
                    checking.writeCheck(checkNum, amount);
                }
                case 5 -> {
                    System.out.print("Enter payment amount: ");
                    amount = scan.nextDouble();
                    cc.MakePayment(amount);
                }
                case 6 -> {
                    System.out.print("Enter charge name: ");
                    scan.nextLine();
                    name = scan.nextLine();
                    System.out.print("Enter charge amount: ");
                    amount = scan.nextDouble();
                    cc.DebitCharge(name, amount);
                }
                case 7 -> savings.display();
                case 8 -> checking.display();
                case 9 -> cc.display();
                case 10 -> System.out.println("Exiting the program");
                default -> System.out.println("Invalid selection. Please try again.");
            }

        } while (choice != 10);

        System.out.println("Thank you for using our services!");
    }
}
