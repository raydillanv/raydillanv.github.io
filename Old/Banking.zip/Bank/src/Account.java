public class Account
{
    //Protected variables
    protected String name;
    protected long taxID;
    protected double balance;
    protected double[] last10Withdraws = new double[10];
    protected double[] last10Deposits = new double [10];
    protected int numDeposits;
    protected int numWithdraws;
    //Constructors
    public Account()
    {

    }
    public Account(String name, long taxID, double b)
    {
        setName(name);
        setTaxID(taxID);
        setBalance(b);

    }
    //Methods
    //Mutators
    public void setName(String name) {
        this.name = name;
    }
    public void setTaxID(long taxID) {
        this.taxID = taxID;
    }
    public void setBalance(double balance) {
        this.balance = balance;
    }
    //Accessors
    public String getName() {
        return name;
    }
    public long getTaxID() {
        return taxID;
    }
    public double getBalance() {
        return balance;
    }
    //other
    public void makeDeposit(double amount) {
        if(amount > 0){
            balance = balance + amount;
            last10Deposits[numDeposits % 10] = amount;
            numDeposits++;
        } else{
            System.out.println("Error: Ensure the deposit is positive.");
        }

    }
    public void display(){
        System.out.println("Your account name is: " + name +
                ".\nYour tax ID is: " + taxID + ".\nYour balance is: " + balance + ".");
    }
}
